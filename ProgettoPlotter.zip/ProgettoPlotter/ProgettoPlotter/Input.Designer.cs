﻿namespace ProgettoPlotter
{
    partial class Input
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAnnulla = new System.Windows.Forms.Button();
            this.buttonInserisci = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.domainUpDownX1 = new System.Windows.Forms.DomainUpDown();
            this.domainUpDownY1 = new System.Windows.Forms.DomainUpDown();
            this.SuspendLayout();
            // 
            // buttonAnnulla
            // 
            this.buttonAnnulla.Location = new System.Drawing.Point(12, 177);
            this.buttonAnnulla.Name = "buttonAnnulla";
            this.buttonAnnulla.Size = new System.Drawing.Size(75, 23);
            this.buttonAnnulla.TabIndex = 0;
            this.buttonAnnulla.Text = "Annulla";
            this.buttonAnnulla.UseVisualStyleBackColor = true;
            this.buttonAnnulla.Click += new System.EventHandler(this.buttonAnnulla_Click);
            // 
            // buttonInserisci
            // 
            this.buttonInserisci.Location = new System.Drawing.Point(161, 177);
            this.buttonInserisci.Name = "buttonInserisci";
            this.buttonInserisci.Size = new System.Drawing.Size(75, 23);
            this.buttonInserisci.TabIndex = 1;
            this.buttonInserisci.Text = "Inserisci";
            this.buttonInserisci.UseVisualStyleBackColor = true;
            this.buttonInserisci.Click += new System.EventHandler(this.buttonInserisci_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Inserire qui le coordinate:";
            // 
            // domainUpDownX1
            // 
            this.domainUpDownX1.Location = new System.Drawing.Point(148, 50);
            this.domainUpDownX1.Name = "domainUpDownX1";
            this.domainUpDownX1.Size = new System.Drawing.Size(44, 20);
            this.domainUpDownX1.TabIndex = 3;
            // 
            // domainUpDownY1
            // 
            this.domainUpDownY1.Location = new System.Drawing.Point(198, 50);
            this.domainUpDownY1.Name = "domainUpDownY1";
            this.domainUpDownY1.Size = new System.Drawing.Size(44, 20);
            this.domainUpDownY1.TabIndex = 4;
            // 
            // Input
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(248, 216);
            this.Controls.Add(this.domainUpDownY1);
            this.Controls.Add(this.domainUpDownX1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonInserisci);
            this.Controls.Add(this.buttonAnnulla);
            this.Name = "Input";
            this.Text = "Input";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAnnulla;
        private System.Windows.Forms.Button buttonInserisci;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DomainUpDown domainUpDownX1;
        private System.Windows.Forms.DomainUpDown domainUpDownY1;
    }
}